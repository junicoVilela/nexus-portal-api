const manualRootBase = window.location.pathname.includes('/paginas/') ? '..' : '.';
async function manualOpenByCodigoTela(codigoTela, basePath = manualRootBase) {
  const response = await fetch(`${basePath}/routes.json`);
  const routes = await response.json();
  const url = routes[codigoTela];
  if (url) window.open(`${basePath}/${url}`, '_blank');
  return url;
}
window.manualOpenByCodigoTela = manualOpenByCodigoTela;
function manualNormalize(text) {
  return (text || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}
function manualSnippet(text, term) {
  const normalizedText = manualNormalize(text);
  const normalizedTerm = manualNormalize(term);
  const index = normalizedText.indexOf(normalizedTerm);
  const start = Math.max(0, index - 42);
  return (text || '').slice(start, start + 118).trim();
}
async function manualLoadSearchIndex() {
  const response = await fetch(`${manualRootBase}/search-index.json`);
  return response.ok ? response.json() : [];
}
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('manual-search');
  if (!input) return;
  const results = document.createElement('div');
  results.id = 'manual-search-results';
  results.className = 'search-results';
  input.insertAdjacentElement('afterend', results);
  let searchIndex = [];
  manualLoadSearchIndex().then(index => searchIndex = index).catch(() => searchIndex = []);
  input.addEventListener('input', () => {
    const term = input.value.trim();
    const normalizedTerm = manualNormalize(term);
    document.querySelectorAll('nav a').forEach(link => {
      const text = `${link.textContent} ${link.dataset.codigoTela || ''}`;
      link.style.display = manualNormalize(text).includes(normalizedTerm) ? 'block' : 'none';
    });
    if (normalizedTerm.length < 2) {
      results.replaceChildren();
      return;
    }
    const matches = searchIndex
      .filter(item => manualNormalize(`${item.titulo} ${item.codigoTela} ${item.texto}`).includes(normalizedTerm))
      .slice(0, 12)
      .map(item => {
        const link = document.createElement('a');
        link.className = 'search-result';
        link.href = `${manualRootBase}/${item.url}`;
        const title = document.createElement('strong');
        title.textContent = item.titulo;
        const meta = document.createElement('span');
        meta.textContent = `${item.codigoTela} · ${manualSnippet(item.texto, term)}`;
        link.append(title, meta);
        return link;
      });
    results.replaceChildren(...matches);
  });
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register(`${manualRootBase}/sw.js`).catch(() => undefined);
  }
});
