async function manualOpenByCodigoTela(codigoTela, basePath = '.') {
  const response = await fetch(`${basePath}/routes.json`);
  const routes = await response.json();
  const url = routes[codigoTela];
  if (url) window.open(`${basePath}/${url}`, '_blank');
  return url;
}
window.manualOpenByCodigoTela = manualOpenByCodigoTela;
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('manual-search');
  if (!input) return;
  input.addEventListener('input', () => {
    const term = input.value.toLowerCase();
    document.querySelectorAll('nav a').forEach(link => {
      link.style.display = link.textContent.toLowerCase().includes(term) ? 'block' : 'none';
    });
  });
});
