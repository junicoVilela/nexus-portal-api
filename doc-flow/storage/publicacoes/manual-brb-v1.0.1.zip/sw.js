const CACHE_NAME = 'manual-brb-1.0.1';
const PRECACHE_URLS = [ "./", "./index.html", "./routes.json", "./search-index.json", "./manifest.json", "./manifest.webmanifest", "./versao.html", "./assets/app.css", "./assets/app.js", "./paginas/visao-geral-do-painel.html", "./paginas/configuracoes-gerais.html", "./paginas/gestao-de-usuarios.html", "./paginas/cadastro-de-clientes.html", "./paginas/vinculos-modulos-paginas.html", "./paginas/cadastro-de-modulos.html", "./paginas/cadastro-de-agencia.html", "./paginas/consulta-de-documentos.html", "./paginas/revisao-de-documento.html", "./paginas/geracao-de-publicacao.html", "./paginas/preview-do-pacote.html", "./paginas/historico-de-publicacoes.html" ];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE_URLS)));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
      return response;
    }))
  );
});
